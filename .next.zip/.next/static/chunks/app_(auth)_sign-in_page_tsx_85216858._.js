(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_4197b2cc._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_27f74358._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
  "static/chunks/node_modules_41ef64f9._.js",
  "static/chunks/_7d2baac3._.js"
],
    source: "dynamic"
});
