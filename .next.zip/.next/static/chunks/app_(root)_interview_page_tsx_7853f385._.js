(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d49fe2aa._.js",
  "static/chunks/_dea4d350._.js"
],
    source: "dynamic"
});
